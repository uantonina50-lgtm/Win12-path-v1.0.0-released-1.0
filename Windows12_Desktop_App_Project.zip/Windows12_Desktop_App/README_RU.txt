WINDOWS 12 — DESKTOP APP

СБОРКА EXE НА WINDOWS 10/11
1. Установите Node.js LTS: https://nodejs.org/
2. Распакуйте папку проекта.
3. Запустите build-windows.bat двойным щелчком.
4. После сборки установщик и portable EXE будут в папке dist.

Вручную:
  npm install
  npm run build:win

Для запуска без EXE:
  npm install
  npm start

ВАЖНО:
- Это настольная оболочка для HTML-имитации Windows 12, а не настоящая ОС.
- Вход остаётся демонстрационным локальным профилем.
- Для сборки нужны интернет и Node.js; сборка Windows EXE надёжнее на Windows x64.
